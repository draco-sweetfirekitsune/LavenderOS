﻿=== Purple Neon Glass Cursor Set ===

By: ツ Mimi Destino ♡ (http://www.rw-designer.com/user/38152)

Download: http://www.rw-designer.com/cursor-set/purpleneonglassmd

Author's description:

 ツ MIMI DESTINO ♥.♡ 

Enjoy the set.
Thanks for download and review ✫✫✫✫✫

 

On pink
http://www.rw-designer.com/cursor-set/pinkneonglassmd

on blue
http://www.rw-designer.com/cursor-set/blueneonglassmd

Other colors for normal select
http://www.rw-designer.com/cursor-set/neonglassnsmd

Green 
http://www.rw-designer.com/cursor-set/greenneonglassmd

Yellow
http://www.rw-designer.com/cursor-set/yellowneonglassmd

--

How to install?

without voice
https://youtu.be/-F9ku2X63_g

see this video with voice
https://youtu.be/VOr3HZHS4fQ

Como instalarlos?
https://youtu.be/EGx6plXI0Yc

How to get cute mouse cursors │FREE│  
https://youtu.be/LaPcuFN_WF8

--

Have any cursor requests? feel free to comment on my profile!
or here http://www.rw-designer.com/entry/3308

social networks --> http://www.rw-designer.com/entry/3309

my favorite cursors set --> http://www.rw-designer.com/cursor-set/donutskawaiimd

Discord: https://discord.gg/3rHVphSH

The Person Select, Location Select, Link Select Hand and Handwriting i add it them myself thats why they look differents


 ..\'\'..\'\'..
 
 


==========

License: Creative Commons - Attribution + Noncommercial

You are free:

* To Share - To copy, distribute and transmit the work.
* To Remix - To adapt the work.

Under the following conditions:

* Attribution - You must attribute the work in the manner specified
  by the author or licensor (but not in any way that suggests that
  they endorse you or your use of the work). For example, if you are
  making the work available on the Internet, you must link to the
  original source.
* Noncommercial - You may not use this work for commercial purposes.